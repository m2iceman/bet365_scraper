const config = {
    "soccer": require("./soccer")
}


module.exports = config;